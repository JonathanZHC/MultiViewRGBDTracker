from __future__ import annotations

import time
from contextlib import ExitStack
from pathlib import Path
from typing import Any

import numpy as np

from .component import SAMTrackingComponent
from .config import Config, load_config
from .data_types import FrameResult, RGBDFrame, TrackerPrediction, TrackerSeed
from .trackers.factory import build_multiview_efficient_tam_tracker


class MultiViewEfficientTAMComponent:
    """Coordinate SAM3 + one shared EfficientTAM predictor across camera views.

    Per-view responsibilities remain independent:
      * SAM3 detection
      * detection/track association
      * persistent semantic track metadata
      * RGB-D post-processing / point clouds
      * profiling

    The EfficientTAM predictor and temporal propagation are shared.  This is the
    layer that turns two independent ``E + N*B1`` camera paths into either:

      execution_mode=sequential: 2E + N*B1
      execution_mode=fixed_batch: E(B=views) + B(views*max_objects_per_view)

    All detector refreshes are coordinated.  If any view requests a periodic or
    anomaly keyframe, every view is reset/reseeded on the same multi-view bundle;
    fixed-batch history therefore stays aligned across all slots.
    """

    def __init__(
        self,
        config: str | Path | Config = "configs/tracking.yaml",
        *,
        camera_names: list[str] | tuple[str, ...] | None = None,
    ) -> None:
        if isinstance(config, (str, Path)):
            config = load_config(config)
        if str(config.tracker.backend) != "efficient_tam":
            raise ValueError(
                "MultiViewEfficientTAMComponent requires "
                "tracker.backend=efficient_tam"
            )

        self.config = config
        self.camera_names = [
            str(name)
            for name in (
                camera_names
                if camera_names is not None
                else config.runtime.camera_names
            )
        ]
        if not self.camera_names:
            raise ValueError("At least one camera is required")

        self.views = [
            SAMTrackingComponent(
                config,
                camera_name=camera_name,
                build_tracker_backend=False,
            )
            for camera_name in self.camera_names
        ]
        self.tracker = build_multiview_efficient_tam_tracker(
            config,
            num_views=len(self.camera_names),
        )

        self.execution_mode = str(
            config.tracker.efficient_tam.get("execution_mode", "sequential")
        ).strip().lower()
        self.max_objects_per_view = int(
            config.tracker.efficient_tam.get(
                "max_objects_per_view",
                max(1, len(config.detector.get("prompts", []))),
            )
        )

    @property
    def fixed_tracking_batch_size(self) -> int:
        return len(self.camera_names) * self.max_objects_per_view

    def prewarm_tracker(self, first_rgbs: list[np.ndarray]) -> dict[str, Any]:
        return dict(self.tracker.prewarm_views(first_rgbs))

    def _make_frames(self, view_inputs: list[dict[str, Any]]) -> list[RGBDFrame]:
        if len(view_inputs) != len(self.views):
            raise ValueError(
                f"Expected {len(self.views)} view inputs, got {len(view_inputs)}"
            )
        frames: list[RGBDFrame] = []
        for view, item in zip(self.views, view_inputs):
            frames.append(
                view.make_frame(
                    item["rgb"],
                    item["depth_m"],
                    fx=float(item["fx"]),
                    fy=float(item["fy"]),
                    cx=float(item["cx"]),
                    cy=float(item["cy"]),
                    timestamp_ns=int(item.get("timestamp_ns", 0)),
                    world_from_camera=item.get("world_from_camera"),
                )
            )
        return frames

    @staticmethod
    def _run_shared_stage(
        views: list[SAMTrackingComponent],
        stage_names: tuple[tuple[str, bool], ...],
        function,
        *args,
        **kwargs,
    ):
        """Record one shared call into every per-view profiler."""
        started = time.perf_counter()
        with ExitStack() as stack:
            for view in views:
                for name, cuda in stage_names:
                    stack.enter_context(view.profiler.stage(name, cuda=cuda))
            result = function(*args, **kwargs)
        elapsed_ms = 1000.0 * (time.perf_counter() - started)
        for view in views:
            view.profiler.record("tracker_total_wall_cpu", elapsed_ms)
        return result

    def _run_coordinated_keyframe(
        self,
        frames: list[RGBDFrame],
    ) -> tuple[list[TrackerPrediction], list[list[TrackerSeed]]]:
        seeds_per_view = [
            view.detect_and_seed(frame)
            for view, frame in zip(self.views, frames)
        ]

        predictions = self._run_shared_stage(
            self.views,
            (
                ("tracker_reinit_gpu", True),
                ("tracker_total_gpu", True),
            ),
            self.tracker.correct_views,
            [frame.rgb for frame in frames],
            seeds_per_view,
        )
        for view, frame in zip(self.views, frames):
            view.mark_keyframe(frame.frame_index)
        return predictions, seeds_per_view

    def process_arrays_batch(
        self,
        view_inputs: list[dict[str, Any]],
    ) -> list[FrameResult]:
        """Process one synchronized set of RGB-D observations."""
        frames = self._make_frames(view_inputs)
        for view in self.views:
            view.begin_external_frame()

        # Propagation is legal only after the shared EfficientTAM states have
        # completed reset -> seed -> prepare.  Per-view semantic tracks are not
        # enough to prove that the tracker state is ready.
        tracker_unprepared = not bool(self.tracker.live_ready)
        periodic_requested = tracker_unprepared or any(
            view.needs_periodic_keyframe(frame.frame_index)
            for view, frame in zip(self.views, frames)
        )

        keyframe = bool(periodic_requested)
        trigger_reasons: list[list[str]] = [[] for _ in self.views]
        update_raw = False

        if periodic_requested:
            all_empty = all(not view.tracks for view in self.views)
            if tracker_unprepared:
                reason = "initial" if all_empty else "tracker_unprepared"
            else:
                reason = "coordinated_periodic"
            trigger_reasons = [[reason] for _ in self.views]
            predictions, _ = self._run_coordinated_keyframe(frames)
        else:
            predictions = self._run_shared_stage(
                self.views,
                (
                    ("tracker_propagate_gpu", True),
                    ("tracker_total_gpu", True),
                ),
                self.tracker.track_views,
                [frame.rgb for frame in frames],
            )

            anomaly_requested = any(
                view.needs_anomaly_keyframe(frame.frame_index, prediction)
                for view, frame, prediction in zip(
                    self.views,
                    frames,
                    predictions,
                )
            )
            if anomaly_requested:
                keyframe = True
                trigger_reasons = [
                    ["coordinated_tracking_anomaly"] for _ in self.views
                ]
                predictions, _ = self._run_coordinated_keyframe(frames)
            else:
                update_raw = True

        results = []
        for view, frame, prediction, reasons in zip(
            self.views,
            frames,
            predictions,
            trigger_reasons,
        ):
            results.append(
                view.finalize_external_prediction(
                    frame,
                    prediction,
                    keyframe=keyframe,
                    trigger_reasons=reasons,
                    update_raw_observations=update_raw,
                )
            )
        return results

    def print_stats(self) -> None:
        for view in self.views:
            view.print_stats()

    def close(self) -> None:
        self.tracker.close()
        for view in self.views:
            view.close()
