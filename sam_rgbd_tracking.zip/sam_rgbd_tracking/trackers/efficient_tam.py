from __future__ import annotations

import threading
import time
from contextlib import nullcontext
from typing import Any, ClassVar

import numpy as np

try:
    import torch
except ImportError:  # pragma: no cover
    torch = None

from ..data_types import TrackerPrediction, TrackerSeed
from .base import GLOBAL_CUDA_LOCK, current_tracker_profiler
from .sam2_adapter import Sam2StyleStreamingTracker
from .streaming_state import StreamingVideoState


def _move_rope_frequency_caches_to_device(
    predictor: Any,
    device: str,
) -> int:
    """Move RoPE frequency tensors to CUDA before the first compiled forward."""
    if torch is None:
        return 0

    target = torch.device(device)
    moved = 0
    attribute_names = (
        "freqs_cis",
        "freqs_cis_q",
        "freqs_cis_k",
    )

    for module in predictor.modules():
        for attribute_name in attribute_names:
            value = getattr(module, attribute_name, None)
            if not torch.is_tensor(value):
                continue
            if value.device == target:
                continue
            setattr(
                module,
                attribute_name,
                value.to(target, non_blocking=False),
            )
            moved += 1

    if moved:
        print(
            "[EfficientTAM] preloaded "
            f"{moved} RoPE frequency tensor(s) on {target} "
            "before first compiled forward",
            flush=True,
        )
    return moved


def _disable_unavailable_hole_fill_extension(predictor: Any) -> None:
    """Avoid repeatedly calling the unavailable optional ``_C`` extension."""
    fill_hole_area = int(getattr(predictor, "fill_hole_area", 0) or 0)
    if fill_hole_area <= 0:
        return

    predictor.fill_hole_area = 0
    print(
        "[EfficientTAM] optional _C hole-filling extension is unavailable in "
        "this container; fill_hole_area forced to 0",
        flush=True,
    )


def _install_memory_attention_clone_boundary(predictor: Any) -> None:
    """Keep CUDAGraph enabled and clone only memory-attention output."""
    if torch is None:
        raise RuntimeError("PyTorch is required for EfficientTAM")

    module = getattr(predictor, "memory_attention", None)
    if module is None:
        raise RuntimeError("EfficientTAM predictor has no memory_attention module")
    if getattr(module, "_sam_rgbd_memory_attention_clone_boundary", False):
        return

    compiled_forward = module.forward

    def clone_safe_forward(*args: Any, **kwargs: Any):
        output = compiled_forward(*args, **kwargs)
        if not torch.is_tensor(output):
            raise TypeError(
                "EfficientTAM memory_attention unexpectedly returned "
                f"{type(output)!r}; expected torch.Tensor"
            )

        profiler = current_tracker_profiler()
        context = (
            profiler.stage("tracker_state_clone_gpu", cuda=True)
            if profiler is not None
            else nullcontext()
        )
        with context:
            return output.clone()

    module.forward = clone_safe_forward
    module._sam_rgbd_memory_attention_clone_boundary = True

    print(
        "[EfficientTAM] selective CUDAGraph safety enabled: "
        "memory_attention output clone only",
        flush=True,
    )


def _synthetic_masks(height: int, width: int, count: int) -> list[np.ndarray]:
    """Create deterministic, non-overlapping prompts for compile warm-up."""
    count = max(1, int(count))
    masks: list[np.ndarray] = []
    margin_y = max(4, height // 12)
    margin_x = max(4, width // 12)
    usable_w = max(count, width - 2 * margin_x)
    cell_w = max(1, usable_w // count)

    for index in range(count):
        mask = np.zeros((height, width), dtype=bool)
        x0 = margin_x + index * cell_w + max(1, cell_w // 6)
        x1 = margin_x + (index + 1) * cell_w - max(1, cell_w // 6)
        y0 = margin_y + (index % 2) * max(1, height // 20)
        y1 = height - margin_y - ((index + 1) % 2) * max(1, height // 20)
        x0 = min(max(0, x0), width - 1)
        x1 = min(max(x0 + 1, x1), width)
        y0 = min(max(0, y0), height - 1)
        y1 = min(max(y0 + 1, y1), height)
        mask[y0:y1, x0:x1] = True
        masks.append(mask)
    return masks


class EfficientTAMTracker(Sam2StyleStreamingTracker):
    """EfficientTAM adapter retaining the native VOS/CUDAGraph fast path.

    The optional pre-warm path deliberately exercises the state shapes that
    otherwise tend to trigger lazy ``torch.compile``/CUDAGraph specialization
    during live operation: seed, several temporal-memory lengths, saturated
    memory, reset/reseed, and propagation after reset.
    """

    _prewarm_lock: ClassVar[threading.Lock] = threading.Lock()
    _prewarm_done: ClassVar[set[tuple[Any, ...]]] = set()

    def __init__(
        self,
        *args: Any,
        prewarm_enabled: bool = True,
        prewarm_object_counts: list[int] | tuple[int, ...] = (1,),
        prewarm_temporal_frames: int = 0,
        prewarm_post_reset_frames: int = 2,
        prewarm_passes: int = 2,
        execution_mode: str = "sequential",
        fixed_num_views: int = 2,
        max_objects_per_view: int = 4,
        **kwargs: Any,
    ) -> None:
        self.execution_mode = str(execution_mode).strip().lower()
        if self.execution_mode not in {"sequential", "fixed_batch"}:
            raise ValueError(
                f"Unsupported EfficientTAM execution_mode={self.execution_mode!r}; "
                "use 'sequential' or 'fixed_batch'."
            )
        self.fixed_num_views = max(1, int(fixed_num_views))
        self.max_objects_per_view = max(1, int(max_objects_per_view))
        self.prewarm_enabled = bool(prewarm_enabled)
        cleaned = sorted({max(1, int(value)) for value in prewarm_object_counts})
        self.prewarm_object_counts = tuple(cleaned or [1])
        self.prewarm_temporal_frames = max(0, int(prewarm_temporal_frames))
        self.prewarm_post_reset_frames = max(1, int(prewarm_post_reset_frames))
        self.prewarm_passes = max(1, int(prewarm_passes))
        super().__init__(*args, **kwargs)

    @property
    def backend_name(self) -> str:
        return "efficient_tam"

    def _cache_key(self) -> tuple[str, ...]:
        return super()._cache_key() + (
            self.execution_mode,
            str(self.fixed_num_views),
            str(self.max_objects_per_view),
        )

    def _build_predictor(self) -> Any:
        from efficient_track_anything.build_efficienttam import (
            build_efficienttam_video_predictor,
        )

        predictor = build_efficienttam_video_predictor(
            config_file=self.config_path,
            ckpt_path=self.checkpoint_path,
            device=self.device,
            mode="eval",
            apply_postprocessing=True,
            vos_optimized=self.vos_optimized,
            execution_mode=self.execution_mode,
            fixed_num_views=self.fixed_num_views,
            max_objects_per_view=self.max_objects_per_view,
        )

        _move_rope_frequency_caches_to_device(predictor, self.device)
        _disable_unavailable_hole_fill_extension(predictor)

        if self.vos_optimized:
            _install_memory_attention_clone_boundary(predictor)
        return predictor

    def _resolved_prewarm_temporal_frames(self) -> int:
        if self.prewarm_temporal_frames > 0:
            return self.prewarm_temporal_frames

        # ``num_maskmem`` is the important shape transition: before saturation,
        # the number of memory tokens grows every frame. Run slightly beyond it
        # so both the growth phase and saturated phase are captured.
        num_maskmem = int(getattr(self.predictor, "num_maskmem", 7) or 7)
        return max(4, min(16, num_maskmem + 2))

    @staticmethod
    def _variant_rgb(rgb: np.ndarray, step: int) -> np.ndarray:
        # Shape-preserving deterministic variation prevents accidental reuse of
        # image-dependent caches while remaining very cheap to construct.
        value = np.ascontiguousarray(rgb, dtype=np.uint8).copy()
        if value.size:
            value[..., step % 3] = np.bitwise_xor(
                value[..., step % 3],
                np.uint8((17 * step) & 0xFF),
            )
        return value

    def _run_prewarm_sequence(
        self,
        rgb: np.ndarray,
        *,
        object_count: int,
        temporal_frames: int,
    ) -> dict[str, Any]:
        if torch is None:
            raise RuntimeError("PyTorch is required for EfficientTAM pre-warm")

        height, width = rgb.shape[:2]
        masks = _synthetic_masks(height, width, object_count)
        buffer_frames = max(self.stream_buffer_frames, temporal_frames + 4)
        stream = StreamingVideoState(
            self.predictor,
            rgb,
            self.offload_video_to_cpu,
            self.offload_state_to_cpu,
            buffer_frames=buffer_frames,
            profiler=None,
            use_gpu_preprocess=self.gpu_preprocess,
            pin_input_memory=self.pin_input_memory,
        )

        propagation_ms: list[float] = []
        reset_propagation_ms: list[float] = []
        try:
            # Seed path, including the object-count-dependent decoder shapes.
            for object_index, mask in enumerate(masks, start=1):
                self.predictor.add_new_mask(
                    inference_state=stream.state,
                    frame_idx=0,
                    obj_id=object_index,
                    mask=mask,
                )
            if torch.cuda.is_available() and str(self.device).startswith("cuda"):
                torch.cuda.synchronize()

            # Exercise every growing memory length and at least one saturated
            # memory state. Synchronization is intentional: compile/capture cost
            # must finish here rather than leaking into the live benchmark.
            for frame_index in range(1, temporal_frames + 1):
                stream.append(self._variant_rgb(rgb, frame_index))
                started = time.perf_counter()
                output = None
                for output in self.predictor.propagate_in_video(
                    stream.state,
                    start_frame_idx=frame_index,
                    max_frame_num_to_track=1,
                    reverse=False,
                ):
                    pass
                if output is None:
                    raise RuntimeError(
                        "EfficientTAM pre-warm propagation returned no output"
                    )
                if torch.cuda.is_available() and str(self.device).startswith("cuda"):
                    torch.cuda.synchronize()
                propagation_ms.append(1000.0 * (time.perf_counter() - started))

            # Warm the exact reset/reseed path used by SAM3 keyframes.
            stream.reset(self._variant_rgb(rgb, 101))
            for object_index, mask in enumerate(masks, start=1):
                self.predictor.add_new_mask(
                    inference_state=stream.state,
                    frame_idx=0,
                    obj_id=object_index,
                    mask=mask,
                )
            if torch.cuda.is_available() and str(self.device).startswith("cuda"):
                torch.cuda.synchronize()

            for local_index in range(1, self.prewarm_post_reset_frames + 1):
                stream.append(self._variant_rgb(rgb, 101 + local_index))
                started = time.perf_counter()
                output = None
                for output in self.predictor.propagate_in_video(
                    stream.state,
                    start_frame_idx=local_index,
                    max_frame_num_to_track=1,
                    reverse=False,
                ):
                    pass
                if output is None:
                    raise RuntimeError(
                        "EfficientTAM post-reset pre-warm returned no output"
                    )
                if torch.cuda.is_available() and str(self.device).startswith("cuda"):
                    torch.cuda.synchronize()
                reset_propagation_ms.append(
                    1000.0 * (time.perf_counter() - started)
                )
        finally:
            stream.close()

        return {
            "object_count": int(object_count),
            "temporal_frames": int(temporal_frames),
            "propagation_ms": propagation_ms,
            "reset_propagation_ms": reset_propagation_ms,
        }

    def prewarm(self, first_rgb: np.ndarray) -> dict[str, Any]:
        """Compile/capture common live EfficientTAM state shapes once.

        The predictor is shared between cameras, therefore the pre-warm itself
        is globally de-duplicated by predictor identity + resolution + settings.
        The second camera simply observes the completed warm-up and returns.
        """
        if not self.prewarm_enabled or not self.vos_optimized:
            return {"enabled": False, "performed": False}
        if torch is None:
            raise RuntimeError("PyTorch is required for EfficientTAM pre-warm")

        rgb = np.ascontiguousarray(first_rgb, dtype=np.uint8)
        if rgb.ndim != 3 or rgb.shape[2] != 3:
            raise ValueError(f"Expected RGB HxWx3 for pre-warm, got {rgb.shape}")

        temporal_frames = self._resolved_prewarm_temporal_frames()
        key = (
            id(self.predictor),
            int(rgb.shape[0]),
            int(rgb.shape[1]),
            self.prewarm_object_counts,
            temporal_frames,
            self.prewarm_post_reset_frames,
            self.prewarm_passes,
            str(self.device),
            bool(self.use_bf16),
        )

        with self._prewarm_lock:
            if key in self._prewarm_done:
                return {
                    "enabled": True,
                    "performed": False,
                    "already_warm": True,
                    "object_counts": list(self.prewarm_object_counts),
                    "temporal_frames": temporal_frames,
                }

            print(
                "[EfficientTAM warmup] starting full VOS pre-warm: "
                f"resolution={rgb.shape[1]}x{rgb.shape[0]}, "
                f"objects={list(self.prewarm_object_counts)}, "
                f"temporal_frames={temporal_frames}, "
                f"post_reset_frames={self.prewarm_post_reset_frames}, "
                f"passes={self.prewarm_passes}",
                flush=True,
            )

            started_total = time.perf_counter()
            results: list[dict[str, Any]] = []
            gpu_context = GLOBAL_CUDA_LOCK if self.serialize_gpu else nullcontext()
            with gpu_context:
                with torch.inference_mode(), self._autocast():
                    for pass_index in range(self.prewarm_passes):
                        for object_count in self.prewarm_object_counts:
                            started = time.perf_counter()
                            result = self._run_prewarm_sequence(
                                rgb,
                                object_count=object_count,
                                temporal_frames=temporal_frames,
                            )
                            result["pass"] = pass_index + 1
                            result["wall_ms"] = 1000.0 * (
                                time.perf_counter() - started
                            )
                            results.append(result)

                            prop = result["propagation_ms"]
                            reset_prop = result["reset_propagation_ms"]
                            prop_max = max(prop) if prop else 0.0
                            reset_max = max(reset_prop) if reset_prop else 0.0
                            print(
                                "[EfficientTAM warmup] "
                                f"pass={pass_index + 1}/{self.prewarm_passes} "
                                f"objects={object_count}: wall={result['wall_ms']:.1f} ms, "
                                f"prop_max={prop_max:.1f} ms, "
                                f"post_reset_max={reset_max:.1f} ms",
                                flush=True,
                            )

            total_ms = 1000.0 * (time.perf_counter() - started_total)
            self._prewarm_done.add(key)

            # The last pass is a useful verification pass. If it is still slow,
            # say so explicitly rather than pretending all specialization is done.
            last_pass = [
                item for item in results if item["pass"] == self.prewarm_passes
            ]
            verify_max = 0.0
            for item in last_pass:
                verify_max = max(
                    verify_max,
                    *(item["propagation_ms"] or [0.0]),
                    *(item["reset_propagation_ms"] or [0.0]),
                )

            print(
                "[EfficientTAM warmup] complete: "
                f"total={total_ms / 1000.0:.2f} s, "
                f"verification_max_propagation={verify_max:.2f} ms",
                flush=True,
            )
            if verify_max > 100.0:
                print(
                    "[EfficientTAM warmup] WARNING: the verification pass still "
                    f"contained a {verify_max:.1f} ms propagation. This suggests "
                    "GPU contention or an un-covered dynamic specialization remains.",
                    flush=True,
                )

            return {
                "enabled": True,
                "performed": True,
                "already_warm": False,
                "total_ms": total_ms,
                "verification_max_ms": verify_max,
                "object_counts": list(self.prewarm_object_counts),
                "temporal_frames": temporal_frames,
                "results": results,
            }


class EfficientTAMMultiViewTracker(EfficientTAMTracker):
    """One EfficientTAM predictor shared by all camera views.

    This class is the bridge used by ``SAMTrackingRGBDBenchmark`` when the
    EfficientTAM backend is selected.  Both execution modes use the same public
    multi-view API exposed by the patched EfficientTAM predictor:

    ``sequential``
        one image-encoder invocation per view + one B=1 propagation per object.

    ``fixed_batch``
        one image-encoder invocation for all views + one fixed all-view/object
        tracking batch.  With two views and three slots per view this is B=6.

    Keyframe correction is intentionally coordinated across all views so every
    slot has the same conditioning/history topology required by fixed batching.
    """

    def __init__(
        self,
        *args: Any,
        num_views: int,
        **kwargs: Any,
    ) -> None:
        self.num_views = max(1, int(num_views))
        kwargs["fixed_num_views"] = self.num_views
        super().__init__(*args, **kwargs)
        self.streams: list[StreamingVideoState | None] = [None] * self.num_views
        self.track_ids_per_view: list[list[int]] = [
            [] for _ in range(self.num_views)
        ]
        # Explicit live-state lifecycle.  Per-view semantic tracks can outlive a
        # tracker reset, so they are not sufficient to decide whether propagation
        # is legal.  Only a successful coordinated prepare moves this to True.
        self._live_prepared = False
        self._prepare_generation = 0

    def _state_prepared(self, state: dict[str, Any]) -> bool:
        if not bool(state.get("multiview_prepared", False)):
            return False
        if self.execution_mode == "fixed_batch":
            return bool(state.get("fixed_batch_prepared", False))
        return True

    def _state_real_ids(self, state: dict[str, Any]) -> list[int]:
        if self.execution_mode == "fixed_batch":
            values = state.get("fixed_batch_real_obj_ids")
            if values is None:
                return []
        else:
            values = state.get("obj_ids", [])
        result: list[int] = []
        for value in values:
            if isinstance(value, (int, np.integer)):
                result.append(int(value))
        return result

    def _states_match_expected_real_objects(self) -> bool:
        if any(stream is None for stream in self.streams):
            return False
        for view_idx, stream in enumerate(self.streams):
            assert stream is not None
            if self._state_real_ids(stream.state) != self.track_ids_per_view[view_idx]:
                return False
        return True

    @property
    def live_ready(self) -> bool:
        if not self._live_prepared:
            return False
        if any(stream is None for stream in self.streams):
            return False
        return all(
            self._state_prepared(stream.state)
            for stream in self.streams
            if stream is not None
        ) and self._states_match_expected_real_objects()

    def _assert_prepared_states(self, states: list[dict[str, Any]]) -> None:
        if len(states) != self.num_views:
            raise RuntimeError(
                f"Expected {self.num_views} live EfficientTAM states, got {len(states)}"
            )
        for view_idx, state in enumerate(states):
            if not self._state_prepared(state):
                raise RuntimeError(
                    "EfficientTAM coordinated prepare did not leave view "
                    f"{view_idx} in a prepared state; execution_mode={self.execution_mode}."
                )
        if not self._states_match_expected_real_objects():
            actual = [
                self._state_real_ids(state)
                for state in states
            ]
            raise RuntimeError(
                "EfficientTAM live state/object mismatch after prepare: "
                f"expected={self.track_ids_per_view}, actual={actual}"
            )

    @staticmethod
    def _clear_fixed_batch_tags(state: dict[str, Any]) -> None:
        # EfficientTAM reset_state() clears native tracking dictionaries but does
        # not know about the integration metadata introduced by our fixed-batch
        # wrapper.  Remove those tags before every coordinated reseed.
        for key in (
            "fixed_batch_real_obj_ids",
            "fixed_batch_real_obj_count",
            "fixed_batch_dummy_obj_ids",
            "fixed_batch_prepared",
            "multiview_prepared",
            "multiview_execution_mode",
        ):
            state.pop(key, None)

    def _new_stream_from_rgb(
        self,
        rgb: np.ndarray,
        *,
        profiler: Any | None = None,
        buffer_frames: int | None = None,
    ) -> StreamingVideoState:
        return StreamingVideoState(
            self.predictor,
            np.ascontiguousarray(rgb, dtype=np.uint8),
            self.offload_video_to_cpu,
            self.offload_state_to_cpu,
            buffer_frames=(
                self.stream_buffer_frames
                if buffer_frames is None
                else max(2, int(buffer_frames))
            ),
            profiler=profiler,
            use_gpu_preprocess=self.gpu_preprocess,
            pin_input_memory=self.pin_input_memory,
        )

    def _reset_or_create_streams(self, rgbs: list[np.ndarray]) -> None:
        # A reset/reseed invalidates the previous propagation contract immediately.
        self._live_prepared = False
        if len(rgbs) != self.num_views:
            raise ValueError(
                f"Expected {self.num_views} RGB views, got {len(rgbs)}"
            )

        for view_idx, rgb in enumerate(rgbs):
            stream = self.streams[view_idx]
            if stream is None:
                stream = self._new_stream_from_rgb(rgb)
                self.streams[view_idx] = stream
            elif self.reuse_state_on_keyframe:
                stream.reset(rgb)
            else:
                stream.close()
                stream = self._new_stream_from_rgb(rgb)
                self.streams[view_idx] = stream
            self._clear_fixed_batch_tags(stream.state)

    def _prediction_from_view_result(
        self,
        view_result: dict[str, Any],
    ) -> TrackerPrediction:
        masks = self._to_numpy_logits(view_result["video_res_masks"])
        ids = [int(value) for value in view_result.get("obj_ids", [])]
        if len(ids) != masks.shape[0]:
            raise RuntimeError(
                "EfficientTAM multi-view output ID/mask count mismatch: "
                f"ids={len(ids)} masks={masks.shape[0]}"
            )
        return TrackerPrediction(
            ids,
            masks,
            self._presence_from_logits(masks),
            {
                "backend": self.backend_name,
                "execution_mode": self.execution_mode,
                "frame_index": int(view_result.get("frame_idx", -1)),
                "num_real_objects": int(
                    view_result.get("num_real_objects", len(ids))
                ),
                "num_dummy_objects": int(
                    view_result.get("num_dummy_objects", 0)
                ),
            },
        )

    def correct_views(
        self,
        rgbs: list[np.ndarray],
        seeds_per_view: list[list[TrackerSeed]],
    ) -> list[TrackerPrediction]:
        """Reset/reseed every view together on one coordinated keyframe."""
        if len(seeds_per_view) != self.num_views:
            raise ValueError(
                f"Expected seeds for {self.num_views} views, "
                f"got {len(seeds_per_view)}"
            )

        for view_idx, seeds in enumerate(seeds_per_view):
            if (
                self.execution_mode == "fixed_batch"
                and len(seeds) > self.max_objects_per_view
            ):
                raise RuntimeError(
                    f"View {view_idx} has {len(seeds)} real objects but "
                    f"max_objects_per_view={self.max_objects_per_view}. "
                    "Increase tracker.efficient_tam.max_objects_per_view or "
                    "reduce detector output before using fixed batching."
                )

        call_started = time.perf_counter()
        with self._gpu_guard():
            with torch.inference_mode(), self._autocast():
                self._reset_or_create_streams(rgbs)
                states = []
                predictions: list[TrackerPrediction] = []

                for view_idx, seeds in enumerate(seeds_per_view):
                    stream = self.streams[view_idx]
                    if stream is None:
                        raise RuntimeError("EfficientTAM stream creation failed")
                    state = stream.state
                    self.track_ids_per_view[view_idx] = [
                        int(seed.track_id) for seed in seeds
                    ]

                    for seed in seeds:
                        self.predictor.add_new_mask(
                            inference_state=state,
                            frame_idx=0,
                            obj_id=int(seed.track_id),
                            mask=np.asarray(seed.mask, dtype=bool),
                        )
                    states.append(state)

                    h, w = rgbs[view_idx].shape[:2]
                    if seeds:
                        masks = np.stack(
                            [seed.mask.astype(np.float32) for seed in seeds],
                            axis=0,
                        )
                        presence = np.asarray(
                            [float(seed.confidence) for seed in seeds],
                            dtype=np.float32,
                        )
                    else:
                        masks = np.empty((0, h, w), dtype=np.float32)
                        presence = np.empty((0,), dtype=np.float32)
                    predictions.append(
                        TrackerPrediction(
                            list(self.track_ids_per_view[view_idx]),
                            masks,
                            presence,
                            {
                                "backend": self.backend_name,
                                "execution_mode": self.execution_mode,
                                "frame_index": 0,
                            },
                        )
                    )

                if self.execution_mode == "sequential":
                    # A view can legitimately contain no currently visible object.
                    # Upstream sequential propagation already knows how to return an
                    # empty result for such a state, but its preflight rejects a zero-
                    # object state. Prepare non-empty views normally and mark empty
                    # views as ready for the zero-object fast path.
                    for state in states:
                        if len(state.get("obj_ids", [])) == 0:
                            state["multiview_prepared"] = True
                            state["multiview_execution_mode"] = "sequential"
                        else:
                            self.predictor.prepare_multiview_states(
                                [state],
                                conditioning_frame_idx=0,
                            )
                else:
                    self.predictor.prepare_multiview_states(
                        states,
                        conditioning_frame_idx=0,
                    )
                self._assert_prepared_states(states)
                self._live_prepared = True
                self._prepare_generation += 1

        self.record_profile(
            "tracker_total_wall_cpu",
            1000.0 * (time.perf_counter() - call_started),
        )
        return predictions

    def track_views(self, rgbs: list[np.ndarray]) -> list[TrackerPrediction]:
        """Append one synchronized frame per camera and propagate once."""
        if len(rgbs) != self.num_views:
            raise ValueError(
                f"Expected {self.num_views} RGB views, got {len(rgbs)}"
            )
        if any(stream is None for stream in self.streams):
            raise RuntimeError(
                "EfficientTAM multi-view tracker is not initialized; "
                "run a coordinated SAM3 keyframe first."
            )
        if not self.live_ready:
            states = [
                stream.state
                for stream in self.streams
                if stream is not None
            ]
            prepared_flags = [self._state_prepared(state) for state in states]
            actual_ids = [self._state_real_ids(state) for state in states]
            raise RuntimeError(
                "EfficientTAM multi-view tracker is not prepared for propagation. "
                "The coordinator must run a coordinated keyframe first. "
                f"execution_mode={self.execution_mode}, "
                f"prepared_flags={prepared_flags}, "
                f"expected_real_ids={self.track_ids_per_view}, "
                f"actual_real_ids={actual_ids}"
            )

        call_started = time.perf_counter()
        with self._gpu_guard():
            with torch.inference_mode(), self._autocast():
                frame_indices: list[int] = []
                states = []
                for view_idx, rgb in enumerate(rgbs):
                    stream = self.streams[view_idx]
                    assert stream is not None
                    frame_indices.append(stream.append(rgb))
                    states.append(stream.state)

                if len(set(frame_indices)) != 1:
                    raise RuntimeError(
                        "Multi-view EfficientTAM streams became misaligned: "
                        f"frame_indices={frame_indices}"
                    )
                frame_idx = frame_indices[0]
                view_results = self.predictor.propagate_multiview_step(
                    states,
                    frame_idx=frame_idx,
                    reverse=False,
                )

                predictions = [
                    self._prediction_from_view_result(result)
                    for result in view_results
                ]

        self.record_profile(
            "tracker_total_wall_cpu",
            1000.0 * (time.perf_counter() - call_started),
        )
        return predictions

    def _prewarm_variant(self, rgb: np.ndarray, step: int) -> np.ndarray:
        return self._variant_rgb(rgb, step)

    def prewarm_views(self, first_rgbs: list[np.ndarray]) -> dict[str, Any]:
        """Compile the selected multi-view execution shape before live tracking."""
        if not self.prewarm_enabled or not self.vos_optimized:
            return {"enabled": False, "performed": False}
        if len(first_rgbs) != self.num_views:
            raise ValueError(
                f"Expected {self.num_views} prewarm views, got {len(first_rgbs)}"
            )

        rgbs = [np.ascontiguousarray(value, dtype=np.uint8) for value in first_rgbs]
        shapes = {value.shape for value in rgbs}
        if len(shapes) != 1:
            raise RuntimeError(
                f"All prewarm views must share one resolution, got {sorted(shapes)}"
            )

        temporal_frames = self._resolved_prewarm_temporal_frames()
        key = (
            id(self.predictor),
            "multiview",
            self.execution_mode,
            self.num_views,
            self.max_objects_per_view,
            tuple(rgbs[0].shape),
            temporal_frames,
            self.prewarm_post_reset_frames,
            self.prewarm_passes,
            str(self.device),
            bool(self.use_bf16),
        )

        with self._prewarm_lock:
            if key in self._prewarm_done:
                return {
                    "enabled": True,
                    "performed": False,
                    "already_warm": True,
                }

            print(
                "[EfficientTAM multi-view warmup] starting: "
                f"execution_mode={self.execution_mode}, views={self.num_views}, "
                f"max_objects_per_view={self.max_objects_per_view}, "
                f"tracking_batch="
                f"{self.num_views * self.max_objects_per_view if self.execution_mode == 'fixed_batch' else 1}, "
                f"temporal_frames={temporal_frames}, passes={self.prewarm_passes}",
                flush=True,
            )

            started_total = time.perf_counter()
            propagation_ms: list[float] = []
            buffer_frames = max(self.stream_buffer_frames, temporal_frames + 4)

            with self._gpu_guard():
                with torch.inference_mode(), self._autocast():
                    for pass_index in range(self.prewarm_passes):
                        temp_streams = [
                            self._new_stream_from_rgb(
                                rgb,
                                buffer_frames=buffer_frames,
                            )
                            for rgb in rgbs
                        ]
                        try:
                            states = [stream.state for stream in temp_streams]
                            for view_idx, state in enumerate(states):
                                masks = _synthetic_masks(
                                    rgbs[view_idx].shape[0],
                                    rgbs[view_idx].shape[1],
                                    self.max_objects_per_view,
                                )
                                for obj_idx, mask in enumerate(masks, start=1):
                                    self.predictor.add_new_mask(
                                        inference_state=state,
                                        frame_idx=0,
                                        obj_id=obj_idx,
                                        mask=mask,
                                    )
                            self.predictor.prepare_multiview_states(
                                states,
                                conditioning_frame_idx=0,
                            )

                            for frame_idx in range(1, temporal_frames + 1):
                                for view_idx, stream in enumerate(temp_streams):
                                    stream.append(
                                        self._prewarm_variant(
                                            rgbs[view_idx],
                                            frame_idx + 31 * view_idx,
                                        )
                                    )
                                started = time.perf_counter()
                                self.predictor.propagate_multiview_step(
                                    states,
                                    frame_idx=frame_idx,
                                    reverse=False,
                                )
                                if torch.cuda.is_available() and str(self.device).startswith("cuda"):
                                    torch.cuda.synchronize(torch.device(self.device))
                                propagation_ms.append(
                                    1000.0 * (time.perf_counter() - started)
                                )
                        finally:
                            for stream in temp_streams:
                                stream.close()

                        print(
                            "[EfficientTAM multi-view warmup] "
                            f"pass={pass_index + 1}/{self.prewarm_passes} complete",
                            flush=True,
                        )

            total_ms = 1000.0 * (time.perf_counter() - started_total)
            self._prewarm_done.add(key)
            verify_max = max(propagation_ms[-temporal_frames:] or [0.0])
            print(
                "[EfficientTAM multi-view warmup] complete: "
                f"total={total_ms / 1000.0:.2f} s, "
                f"verification_max={verify_max:.2f} ms",
                flush=True,
            )
            return {
                "enabled": True,
                "performed": True,
                "total_ms": total_ms,
                "verification_max_ms": verify_max,
                "execution_mode": self.execution_mode,
                "views": self.num_views,
                "max_objects_per_view": self.max_objects_per_view,
            }

    def close_views(self) -> None:
        self._live_prepared = False
        for stream in self.streams:
            if stream is not None:
                stream.close()
        self.streams = [None] * self.num_views
        self.track_ids_per_view = [[] for _ in range(self.num_views)]

    def close(self) -> None:
        self.close_views()
