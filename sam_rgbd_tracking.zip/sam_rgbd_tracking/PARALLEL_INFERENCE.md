# Parallel multi-camera inference

This package keeps the existing sequential execution path and adds a separate
parallel execution path.

## Select the mode

Add one field under `runtime` in the existing tracking YAML:

```yaml
runtime:
  inference_mode: sequential   # sequential | parallel
```

`sequential` is the default when the field is absent and preserves the previous
single-GPU-owner behavior.

`parallel` is valid only when `runtime.camera_names` contains at least two
cameras.

## Parallel execution

The camera count is dynamic. For every configured camera the node creates:

- one permanent camera worker thread,
- one CUDA stream,
- one private SAM3 model + processor,
- one private EfficientTAM or SAM-MT predictor,
- one private streaming tracker state.

The model stack is built, compiled, and pre-warmed on the same permanent worker
thread that will use it at runtime. Model construction and tracker pre-warm are
serialized across cameras; live inference is not.

The old cross-camera `GLOBAL_CUDA_LOCK` is therefore still available for the
sequential path, while parallel live inference bypasses it. EfficientTAM and
SAM-MT keep their existing pre-warm locks.

## VRAM check

Parallel startup actually constructs all private camera model stacks before live
tracking. If model loading or pre-warm raises CUDA out-of-memory, startup is
stopped with:

```text
Parallel inference cannot be used.
```

No automatic fallback to sequential mode is performed.

## Frame and mask synchronization

Parallel mode assembles camera packets by their common ROS header timestamp.
Only a complete timestamp group containing every configured camera is
dispatched.

Each group has two barriers:

1. a start barrier immediately before component inference, so all camera
   threads launch the same timestamp together;
2. an output barrier after each camera has produced its mask/result, so no
   camera publishes before every camera has finished that timestamp.

If workers are busy, the whole timestamp group is dropped. Individual cameras
never independently skip a dispatched group, so tracker frame indices remain
lockstep across views.

The input camera stream remains the 30 Hz clock. There is no additional worker
sleep/rate limiter. If the parallel GPU execution can keep up, every camera
processes every 30 Hz timestamp group. Periodic SAM3 keyframes can still exceed
the 33.3 ms frame budget; this version parallelizes the per-camera SAM3 copies
but does not yet move SAM3 into an asynchronous correction lane.

## Parallel compile policy

The sequential path keeps the existing CUDAGraph-optimized compile behavior.
The parallel path uses private per-camera models and CUDA streams, but compiles
SAM-MT and EfficientTAM with `max-autotune-no-cudagraphs`. This keeps
`torch.compile`/Inductor autotuning while avoiding cross-thread CUDA Graph
capture failures seen when several permanent camera threads capture graphs in
one process. Model construction and pre-warm are still serialized.
